﻿namespace _01.ReformatCode
{
    using System;
    using System.Collections;

    public class OrderedBag : IList
    {
        public IEnumerator GetEnumerator()
        {
            throw new NotImplementedException();
        }

        public void CopyTo(Array array, int index)
        {
            throw new NotImplementedException();
        }

        public int Count { get; private set; }

        public object SyncRoot { get; private set; }

        public bool IsSynchronized { get; private set; }

        public int Add(object value)
        {
            throw new NotImplementedException();
        }

        public bool Contains(object value)
        {
            throw new NotImplementedException();
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        public int IndexOf(object value)
        {
            throw new NotImplementedException();
        }

        public void Insert(int index, object value)
        {
            throw new NotImplementedException();
        }

        public void Remove(object value)
        {
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            throw new NotImplementedException();
        }

        public object this[int index]
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public bool IsReadOnly { get; private set; }

        public bool IsFixedSize { get; private set; }

        public static object ViewEventsToShow { get; set; }

        public object RangeFrom(Event @event, bool b)
        {
            throw new NotImplementedException();
        }
    }
}
