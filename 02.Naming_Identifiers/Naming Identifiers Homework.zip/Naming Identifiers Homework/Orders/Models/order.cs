﻿namespace Orders
{
    public class Order
    {
        public int ID { get; set; }

        public int ProductID { get; set; }

        public int Quant { get; set; }

        public decimal Discount { get; set; }
    }
}
