﻿namespace Logger.Models
{
    public enum ReportLevel
    {
        Info,
        Warn,
        Error,
        Critical,
        Fatal
    }
}
