﻿namespace Abstraction
{
    public interface IFigure
    {
        double CalculationPerimeter();

        double CalculationSurface();
    }
}
